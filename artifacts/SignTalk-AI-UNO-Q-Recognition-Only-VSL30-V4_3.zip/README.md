# SignTalk AI UNO Q — VSL-30 V4.3

Import this ZIP in Arduino App Lab and press **Run**. The SignTalk AI Edge AI
service is available at `http://UNO_Q_IP:8082/predict` and includes one model only:
VSL-30 V4.3.

The inference pipeline is aligned with the V4.3 training notebook:

1. Uniformly select up to 32 submitted camera or video frames, then extract pose and hand landmarks.
2. Reconstruct temporarily missing joints per landmark across time.
3. Apply the training-time camera normalization and body normalization.
4. Linearly resample landmarks to the required `[1, 48, 75, 4]` tensor.
5. Run the CPU ONNX classifier and return the top predictions.

Configure the frontend with `EXPO_PUBLIC_EDGE_AI_URLS=http://UNO_Q_IP:8082`.
